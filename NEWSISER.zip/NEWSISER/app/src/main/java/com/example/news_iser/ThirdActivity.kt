package com.example.news_iser

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ThirdActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)

        // Mostrar el texto de la información adicional
        val infoTextView: TextView = findViewById(R.id.infoTextView)
        infoTextView.text = "Aquí puedes añadir mucha más información sobre los programas deportivos..."
    }
}
