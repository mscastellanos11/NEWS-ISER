package com.example.news_iser

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Botón "Acceder" que abre SecondActivity
        val accessButton = findViewById<Button>(R.id.accessButton)
        accessButton.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            startActivity(intent)
        }

        // Configuración de los botones "más información" en la pantalla principal
        val moreInfoSports = findViewById<TextView>(R.id.moreInfoSports)
        val moreInfoElectives = findViewById<TextView>(R.id.moreInfoElectives)
        val moreInfoEvents = findViewById<TextView>(R.id.moreInfoEvents)
        val moreInfoCalendar = findViewById<TextView>(R.id.moreInfoCalendar)

        moreInfoSports.setOnClickListener {
            openInfoActivity("Programas Deportivos")
        }

        moreInfoElectives.setOnClickListener {
            openInfoActivity("Electivas")
        }

        moreInfoEvents.setOnClickListener {
            openInfoActivity("Eventos")
        }

        moreInfoCalendar.setOnClickListener {
            openInfoActivity("Calendario Académico")
        }
    }

    private fun openInfoActivity(section: String) {
        // Si la sección es "Programas Deportivos", abrir ThirdActivity
        when (section) {
            "Programas Deportivos" -> {
                val intent = Intent(this, ThirdActivity::class.java)
                startActivity(intent)
            }
            "Electivas" -> {
                // Si la sección es "Electivas", abrir FourthActivity
                val intent = Intent(this, FourthActivity::class.java)
                startActivity(intent)
            }
            "Eventos" -> {
                // Si la sección es "Eventos", abrir FifthActivity
                val intent = Intent(this, FifthActivity::class.java)
                startActivity(intent)
            }
            else -> {
                // Muestra un Toast con el nombre de la sección seleccionada
                Toast.makeText(this, "Información sobre: $section", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
