package com.example.news_iser

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class FourthActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fourth)

        // Aquí puedes añadir lógica adicional para cargar la información específica de "Electivas"
    }
}
