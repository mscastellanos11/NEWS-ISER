package com.example.news_iser

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class FifthActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fifth)

        // Aquí puedes añadir lógica adicional para cargar la información específica de "Eventos"
    }
}
